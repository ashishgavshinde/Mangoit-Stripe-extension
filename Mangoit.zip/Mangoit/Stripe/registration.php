<?php
/**
 * Created by Mangoit.
 * Author: MangoIT Solutions
 * Date: 07/05/2016
 * Time: 13:58
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mangoit_Stripe',
    __DIR__
);
