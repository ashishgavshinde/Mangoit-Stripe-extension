<?php
/**
 * Created by PhpStorm.
 * User: Mangoit
 * Date: 01/04/2017
 * Time: 16:34
 */

namespace Mangoit\Stripe\Helper;

class Logger extends \Monolog\Logger
{
}
