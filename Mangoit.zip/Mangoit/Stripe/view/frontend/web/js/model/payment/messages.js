/**
 * Created by Mangoit on 2/27/17.
 */
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
define(
    [
        'Magento_Ui/js/model/messages'
    ],
    function (Messages) {
        'use strict';

        return new Messages();
    }
);